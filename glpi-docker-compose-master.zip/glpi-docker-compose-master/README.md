# GLPI con Docker compose

## Ingresar en "Localhost:8200" o "IP:8200" 

### Configurando GLPI

host: mysql,
usuario: glpi,
contraseña: glpi
### 
Los usuarios / contraseñas predeterminadas son:
root/root contraseña israel
glpi/glpi para la cuenta de administrador
tech/tech para la cuenta de técnico
normal/normal para la cuenta normal
post-only/postonly para la cuenta de sólo lectura

